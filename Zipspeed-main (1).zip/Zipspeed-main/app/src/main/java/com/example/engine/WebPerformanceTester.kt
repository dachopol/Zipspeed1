package com.example.engine

import com.example.model.WebSiteTest
import com.example.model.WebTestState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.job
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class WebPerformanceTester {

    private val client = OkHttpClient.Builder()
        .connectTimeout(1200, TimeUnit.MILLISECONDS)
        .readTimeout(1500, TimeUnit.MILLISECONDS)
        .callTimeout(1800, TimeUnit.MILLISECONDS)
        .followRedirects(true)
        .build()

    private val defaultWebsites = listOf(
        WebSiteTest("google", "Google Search", "https://www.google.com/generate_204", "Search Engine"),
        WebSiteTest("cloudflare", "Cloudflare CDN", "https://1.1.1.1", "CDN / DNS"),
        WebSiteTest("youtube", "YouTube Edge", "https://www.youtube.com/generate_204", "Streaming"),
        WebSiteTest("wikipedia", "Wikipedia CDN", "https://en.wikipedia.org", "Content / Encyclopedia"),
        WebSiteTest("pantip", "Pantip", "https://pantip.com", "Local Forum"),
        WebSiteTest("sanook", "Sanook News", "https://www.sanook.com", "News Portal")
    )

    private val _state = MutableStateFlow(WebTestState(sites = defaultWebsites))
    val state: StateFlow<WebTestState> = _state.asStateFlow()

    @Volatile
    private var activeCall: Call? = null

    suspend fun runWebTest(): WebTestState = coroutineScope {
        cancelTest()
        _state.value = WebTestState(
            isTesting = true,
            sites = defaultWebsites.map { it.copy(statusText = "กำลังทดสอบ...", latencyMs = 0, ttfbMs = 0) },
            isCompleted = false
        )

        val updatedSites = mutableListOf<WebSiteTest>()
        var totalLatency = 0
        var successCount = 0

        for (site in defaultWebsites) {
            if (!isActive || !_state.value.isTesting) break

            var measuredLatency = 0
            var measuredTtfb = 0
            var statusCode = 0
            var isSuccess = false
            val startTime = System.currentTimeMillis()

            // Strict 1.2s timeout per site with instant socket abortion
            withTimeoutOrNull(1200L) {
                try {
                    val request = Request.Builder()
                        .url(site.domain)
                        .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Zipspeed/35.0)")
                        .header("Accept", "*/*")
                        .head()
                        .build()

                    val call = client.newCall(request)
                    activeCall = call

                    val cancelHandler = coroutineContext.job.invokeOnCompletion {
                        try { call.cancel() } catch (_: Exception) {}
                    }

                    try {
                        withContext(Dispatchers.IO) {
                            call.execute().use { response ->
                                val elapsed = (System.currentTimeMillis() - startTime).toInt().coerceAtLeast(1)
                                measuredLatency = elapsed
                                // execute() returns after response headers are available; use that measured time
                                // rather than inventing a synthetic TTFB percentage.
                                measuredTtfb = elapsed
                                statusCode = response.code
                                isSuccess = response.isSuccessful || statusCode in 200..399
                            }
                        }
                    } finally {
                        cancelHandler.dispose()
                        activeCall = null
                    }
                } catch (_: Exception) {
                    activeCall = null
                }
            }

            if (isSuccess && measuredLatency > 0) {
                totalLatency += measuredLatency
                successCount++
            }

            val statusText = when {
                !isSuccess || measuredLatency <= 0 -> "ไม่พร้อมใช้งาน (Unavailable)"
                measuredLatency < 45 -> "เร็วมาก (Fast)"
                measuredLatency < 120 -> "ดีมาก (Good)"
                measuredLatency < 250 -> "ปานกลาง (Fair)"
                else -> "ช้า (Slow)"
            }

            val resultSite = site.copy(
                latencyMs = measuredLatency,
                ttfbMs = measuredTtfb,
                statusCode = statusCode,
                statusText = statusText,
                isSuccess = isSuccess
            )
            updatedSites.add(resultSite)

            _state.update { current ->
                val currentSites = current.sites.toMutableList()
                val idx = currentSites.indexOfFirst { it.id == site.id }
                if (idx >= 0) currentSites[idx] = resultSite
                current.copy(sites = currentSites)
            }

            delay(60L)
        }

        val avgLatency = if (successCount > 0) totalLatency / successCount else 0
        val baseScore = if (successCount > 0) {
            (100 - (avgLatency * 0.18).toInt()).coerceIn(0, 99)
        } else {
            0
        }

        val finalState = _state.value.copy(
            isTesting = false,
            overallScore = baseScore,
            sites = updatedSites,
            isCompleted = true
        )
        _state.value = finalState
        finalState
    }

    fun cancelTest() {
        try {
            activeCall?.cancel()
        } catch (_: Exception) {}
        activeCall = null
        _state.value = _state.value.copy(isTesting = false)
    }

    fun reset() {
        cancelTest()
        _state.value = WebTestState(sites = defaultWebsites)
    }
}
